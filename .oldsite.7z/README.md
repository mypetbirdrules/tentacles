#The Tentacle Project

---------------------

The tentacle project is a small effort to build a clean, flat, and minimal porn site. Unlike other porn sites, The Tentacle Project has strict guidelines of ads and forbids intrusive ads  
that spread malware to create a superior jacking experience. Tired of porn sites as dirty and disgusting as your old gym sock? Help with The 
Tentacle Project today!  
